import { useEffect } from 'react';
import { useForm } from 'react-hook-form';
import { useLocation, useNavigate, Link } from 'react-router-dom';
import logo from '../assets/images/logo.png';
import { InputField } from '../components/InputField';
import { PasswordField } from '../components/PasswordField';
import { SelectField } from '../components/SelectField';
import { SubmitButton } from '../components/SubmitButton';

export const StudentRegister = () => {
  const { register, handleSubmit, setValue, watch, formState: { errors } } = useForm();
  const navigate = useNavigate();
  const location = useLocation();

  const params = new URLSearchParams(location.search);
  const socialName = params.get("name");
  const socialEmail = params.get("email");

  useEffect(() => {
    if (socialName) setValue("name", socialName);
    if (socialEmail) setValue("email", socialEmail);
  }, [socialName, socialEmail, setValue]);

  const hasGroupValue = watch("hasGroup");

  const onSubmit = async (data) => {

    // Limpar WhatsApp
    data.whatsapp = data.whatsapp.replace(/\D/g, '');

    // Remover confirmPassword antes de enviar
    const { confirmPassword: _confirmPassword, ...dataToSend } = data;

    navigate("/warname", { state: { ...dataToSend } });
  };
  return (
    <div className='flex flex-col justify-center items-center px-4 w-full sm:w-[500px] mx-auto my-8'>
      <div className='w-[180px] mb-3'>
        <img src={logo} alt="logo da +prati" className='w-full' />
      </div>
      <form className='w-full' onSubmit={handleSubmit(onSubmit)}>
        <InputField
          name='name'
          type='text'
          placeholder='Nome Completo'
          label="Nome Completo *"
          register={register}
          error={errors.name?.message}
          disabled={Boolean(socialEmail)}
          validation={{
            required: 'Nome de usuário é obrigatório'
          }}
        />
        <InputField
          name="email"
          type="email"
          placeholder="E-mail"
          label="E-mail *"
          register={register}
          disabled={Boolean(socialEmail)}
          error={errors.email?.message}
          validation={{
            required: "Email é obrigatório",
            pattern: {
              value: /^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$/,
              message: "Email inválido",
            },
          }}
        />
        <PasswordField
          name="password"
          placeholder="Senha"
          label="Senha *"
          register={register}
          error={errors.password?.message}
          requireStrong={true}
        />

        <PasswordField
          name="confirmPassword"
          placeholder="Confirme sua senha"
          label="Confirmar Senha *"
          register={register}
          error={errors.confirmPassword?.message}
          validation={{
            required: "Confirmação de senha é obrigatória",
            validate: (value) => {
              const password = watch("password");
              if (value !== password) {
                return "As senhas não coincidem";
              }
              return true;
            },
          }}
        />

        <InputField
          name="whatsapp"
          type="tel"
          placeholder="Digite seu whatsapp"
          label="WhatsApp *"
          register={register}
          error={errors.whatsapp?.message}
          validation={{
            required: "WhatsApp é obrigatório",
            pattern: {
              value: /^[\d\s\-()]+$/,
              message: "Digite um número válido",
            },
          }}
        />

        <SelectField
          name="groupClass"
          label="Turma"
          register={register}
          error={errors.groupClass}
          required={true}
          options={[
            { value: "T1", label: "T1" },
            { value: "T2", label: "T2" }
          ]}
        />

        <InputField
          name="hasGroup"
          type="radio"
          label="Já possui grupo? *"
          register={register}
          error={errors.hasGroup?.message}
          validation={{
            required: "Selecione uma opção"
          }}
          options={[
            { value: "sim", label: "Sim" },
            { value: "nao", label: "Não" }
          ]}
        />
        {hasGroupValue === "nao" && (
          <InputField
            name="wantsGroup"
            type="radio"
            label="Deseja trabalhar em grupo? *"
            register={register}
            error={errors.wantsGroup?.message}
            validation={{
              required: "Selecione uma opção"
            }}
            options={[
              { value: "sim", label: "Sim" },
              { value: "nao", label: "Não, prefiro trabalhar sozinho" }
            ]}
          />
        )}
        <InputField
          name="type"
          type="hidden"
          value="STUDENT"
          register={register}
        />
        <SubmitButton label='Registrar' aria-label="Registrar" />
        <Link to="/login" className="text-center text-sm text-red-primary font-bold hover:text-red-secondary mt-5 block">Já tem conta? Acesse aqui</Link>
      </form>
    </div>
  );
};
